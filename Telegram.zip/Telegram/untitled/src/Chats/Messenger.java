package Chats;

import java.util.ArrayList;
import Chats.Channel;
import Users.User;

public class Messenger {
    private final static ArrayList<Channel> channels = new ArrayList<Channel>();
    private final static ArrayList<String> channelIds = new ArrayList<String>();

    private final static ArrayList<Group> groups = new ArrayList<>();
    private final static ArrayList<String> groupIds = new ArrayList<>();
    private static User currentUser;
    private final static ArrayList<User> users = new ArrayList<>();
    private final static ArrayList<String> userIds = new ArrayList<>();

    public static ArrayList<Channel> getChannels() {
        return channels;
    }

    public static ArrayList<String> getChannelIds() {
        return channelIds;
    }

    public static void addGroup(Group group) {
        groups.add(group);
        groupIds.add(group.getId());
    }

    public static void addChannel(Channel channel) {
        channels.add(channel);
        channelIds.add(channel.getId());
    }

    public static void addUser(User user) {
        users.add(user);
        userIds.add(user.getId());
    }
    public static Group getGroupById(String id) {
        int index = groupIds.indexOf(id);
        if (index == -1)
            return null;
        return groups.get(groupIds.indexOf(id));
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public static Channel getChannelById(String id) {
        return channels.get(channelIds.indexOf(id));
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static PrivateChat getMemberById(String id) {
        if (User.getAllIds().indexOf(id) == -1)
            return null;
        User next = User.getAllUsers().get(User.getAllIds().indexOf(id));
        for (Chat i : currentUser.getChats()) {
            if (i instanceof PrivateChat && i.getMembers().contains(next))
                return (PrivateChat) i;
        }
        return null;
    }
}
