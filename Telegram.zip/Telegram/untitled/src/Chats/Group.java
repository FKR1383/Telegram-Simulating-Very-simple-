package Chats;

import Users.User;

public class Group extends Chat {
    public Group(User admin, String id, String name) {
        super(admin, id, name);
        this.typeOfChat = "group";
        Messenger.addGroup(this);
    }
}
