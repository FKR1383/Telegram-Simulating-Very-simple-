package Chats;
import Message.Message;
import Users.User;

import java.util.ArrayList;

public class Chat {
    private ArrayList<User> members = new ArrayList<User>();
    private ArrayList<Message> messages = new ArrayList<Message>();
    private String id , name;
    protected String typeOfChat;
    private User Owner;

    public Chat(User admin, String id , String name) {
        this.id = id;
        this.name = name;
        this.Owner = admin;
        this.members.add(admin);
    }

    public String getTypeOfChat() {
        return this.typeOfChat;
    }

    public ArrayList<User> getMembers() {
        return members;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }

    public void addMember(User user) {
        this.members.add(user);
    }

    public void addMessage(Message message) {
        this.messages.add(message);
    }

    public User getOwner() {
        return Owner;
    }
}
