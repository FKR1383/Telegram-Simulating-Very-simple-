package Chats;

import Users.User;

public class PrivateChat extends Chat{
    public PrivateChat(User admin, String id, String name , User second) {
        super(admin, id, name);
        this.typeOfChat = "private chat";
        this.addMember(second);
    }

}
