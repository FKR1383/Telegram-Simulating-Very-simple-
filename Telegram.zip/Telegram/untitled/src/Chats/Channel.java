package Chats;

import java.util.ArrayList;
import Users.User;

public class Channel extends Chat{


    public Channel(User admin , String id, String name) {
        super(admin, id, name);
        this.typeOfChat = "channel";
    }
}
