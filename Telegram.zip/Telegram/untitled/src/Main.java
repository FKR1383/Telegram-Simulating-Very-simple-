import Chats.Messenger;
import Menu.LoginMenu;

import java.util.*;

public class Main {
    public static void main(String[] args){
        LoginMenu menu = new LoginMenu();
        Scanner myScanner = new Scanner(System.in);
        while (menu.isRunning_program()) {
            menu.run(myScanner);
        }
    }
}
