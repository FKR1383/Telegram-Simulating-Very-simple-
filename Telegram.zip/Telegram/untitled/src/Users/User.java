package Users;

import Chats.*;
import Chats.Messenger;

import java.util.ArrayList;
import java.util.Collections;

public class User {
    private final static ArrayList<User> allUsers = new ArrayList<>();
    private ArrayList<Chat> chatsInOrder = new ArrayList<Chat>();
    public void changeOrder(Chat chat) {
        int index = chatsInOrder.indexOf(chat);
        if (index != -1) {
            chatsInOrder.remove(index);
        }
        chatsInOrder.add(chat);
    }

    public ArrayList<Chat> getChatsInOrder() {
        return chatsInOrder;
    }
    private final static ArrayList<String> allIds = new ArrayList<>();
    private ArrayList<Chat> chats = new ArrayList<>();
    private ArrayList<String> chatIds = new ArrayList<>();

    private ArrayList<Chat> channels = new ArrayList<>();
    private ArrayList<String> channelIds = new ArrayList<>();

    private ArrayList<Chat> groups = new ArrayList<>();
    private ArrayList<String> groupIds = new ArrayList<>();

    private ArrayList<Chat> privateChats = new ArrayList<>();
    private ArrayList<String> privateChatIds = new ArrayList<>();

    public ArrayList<Chat> getChats() {
        return chats;
    }
    private String id , name , password;

    public User(String id , String name , String password) {
        this.id = id;
        this.password = password;
        this.name = name;
        allUsers.add(this);
        allIds.add(id);
        Messenger.addUser(this);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public static ArrayList<User> getAllUsers() {
        return allUsers;
    }

    public static ArrayList<String> getAllIds() {
        return allIds;
    }

    public void addChat(Chat chat) {
        chats.add(chat);
        chatIds.add(chat.getId());
    }

    public void addGroup(Group group) {
        groups.add(group);
        groupIds.add(group.getId());
    }

    public void addChannel(Channel channel) {
        channels.add(channel);
        channelIds.add(channel.getId());
    }

    public void addPrivateChat(PrivateChat pv) {
        privateChats.add(pv);
        privateChatIds.add(pv.getId());
    }
    public Group getGroupById(String id) {
        for (int i = 0; i != chatIds.size(); i++) {
            if (chatIds.get(i).equals(id) && chats.get(i) instanceof Group) {
                return (Group)chats.get(i);
            }
        }
        return null;
    }

    public Channel getChannelById(String id) {
        for (int i = 0; i != chatIds.size(); i++) {
            if (chatIds.get(i).equals(id) && chats.get(i) instanceof Channel)
                return (Channel)chats.get(i);
        }
        return null;
    }

    public PrivateChat getPrivateChatById(String id) {
        for (int i = 0; i != chatIds.size(); i++) {
            if (chatIds.get(i).equals(id) && chats.get(i) instanceof PrivateChat)
                return (PrivateChat) chats.get(i);
        }
        return null;
    }


}
