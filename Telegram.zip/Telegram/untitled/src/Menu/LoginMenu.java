package Menu;

import Users.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginMenu {
    private static boolean successful_login = false;
    private static User now_user;
    private boolean running_program = true;
    public boolean isRunning_program() {
        return this.running_program;
    }

    public void setRunning_program(boolean run) {
        this.running_program = run;
    }

    static MessengerMenu messengerMenu = new MessengerMenu();

    private static boolean checkUsername(String username) {
        String correctRegex = "[a-zA-Z0-9_]+";
        Pattern correctPattern = Pattern.compile(correctRegex);
        Matcher correctMatcher = correctPattern.matcher(username);
        return correctMatcher.matches();
    }
    private static boolean checkPassword(String password) {
        if (password.length() < 8 || password.length() > 32)
            return false;
        String regex = "[0-9]";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        if (!matcher.find()) {
            return false;
        }
        regex = "[a-z]";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(password);
        if (!matcher.find()) {
            return false;
        }
        regex = "[A-Z]";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(password);
        if (!matcher.find()) {
            return false;
        }
        regex = "[*.!@$%^&(){}\\[\\]:;<>,?/~_+\\-=|]";
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(password);
        if (!matcher.find()) {
            return false;
        }
        return true;
    }

    private String register(Matcher matcher) {
        String id = matcher.group("id");
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!checkUsername(username)) {
            return "Username's format is invalid!";
        }
        if (!checkPassword(password)) {
            return "Password is weak!";
        }
        if (User.getAllIds().contains(id)) {
            return "A user with this ID already exists!";
        }
        new User(id , username , password);
        return "User has been created successfully!";
    }

    private String login(Matcher matcher) {
        String id = matcher.group("id");
        String password = matcher.group("password");
        if (!User.getAllIds().contains(id)) {
            return "No user with this id exists!";
        }
        User user = User.getAllUsers().get(User.getAllIds().indexOf(id));
        if (!user.getPassword().equals(password)) {
            return "Incorrect password!";
        }
        successful_login = true;
        now_user = user;
        return "User successfully logged in!";
    }
    public void run(Scanner mainScanner) {
        String command = mainScanner.nextLine();
        Matcher registerMatcher = Commands.getMatcher(command , Commands.registerRegex);
        Matcher loginMatcher = Commands.getMatcher(command , Commands.loginRegex);
        if (registerMatcher.matches()) {
            System.out.println(register(registerMatcher));
        } else if(loginMatcher.matches()) {
            System.out.println(login(loginMatcher));
            if (successful_login) {
                messengerMenu.setCurrentUser(now_user);
                messengerMenu.run(mainScanner);
                now_user = null;
                successful_login = false;
            }
        } else if (command.matches("exit")) {
            running_program = false;
        } else {
            System.out.println("Invalid command!");
        }
    }
}
