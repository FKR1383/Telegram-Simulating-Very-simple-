package Menu;
import Chats.Channel;
import Chats.Chat;
import Chats.Group;
import Chats.PrivateChat;
import Message.Message;
import Users.User;
import java.util.*;
import java.util.regex.Matcher;

public class ChatMenu {
    private Chat chat;
    private User currentUser;

    public ChatMenu(Chat chat, User currentUser) {
        this.chat = chat;
        this.currentUser = currentUser;
    }

    public void run(Scanner scanner , Chat chat) {
        String command = scanner.nextLine();
        Matcher sendMessageMatcher = Commands.getMatcher(command , Commands.sendMessageRegex);
        Matcher addMemberMatcher = Commands.getMatcher(command , Commands.addMemberRegex);
        while (true) {
            if (sendMessageMatcher.matches()) {
                System.out.println(sendMessage(sendMessageMatcher));
            } else if (addMemberMatcher.matches()) {
                System.out.println(addMember(addMemberMatcher));
            } else if (command.matches("show all messages")) {
                System.out.println(showMessages());
            } else if (command.matches("show all members")) {
                System.out.println(showMembers());
            } else if(command.matches("back")) {
                break;
            } else {
                System.out.println("Invalid command!");
            }
            command = scanner.nextLine();
            sendMessageMatcher = Commands.getMatcher(command , Commands.sendMessageRegex);
            addMemberMatcher = Commands.getMatcher(command , Commands.addMemberRegex);
        }
    }

    private String sendMessage(Matcher matcher) {
        if (chat instanceof Channel && !chat.getOwner().equals(currentUser)) {
            return "You don't have access to send a message!";
        }
        String message = matcher.group("message");
        Message newMessage = new Message(currentUser , message);
        chat.addMessage(newMessage);
        if (chat instanceof PrivateChat) {
            currentUser.changeOrder(chat);
            User next;
            if (chat.getMembers().get(0).equals(currentUser)) {
                next = chat.getMembers().get(1);
            } else {
                next = chat.getMembers().get(0);
            }
            if (next.equals(currentUser))
                return "Message has been sent successfully!";
            Chat mychat = next.getPrivateChatById(currentUser.getId());
            mychat.addMessage(newMessage);
            next.changeOrder(mychat);
        } else {
            Iterator<User> it = chat.getMembers().iterator();
            while (it.hasNext()) {
                it.next().changeOrder(chat);
            }
        }
        return "Message has been sent successfully!";
    }

    private String addMember(Matcher matcher) {
        String id = matcher.group("id");
        if (chat instanceof PrivateChat) {
            return "Invalid command!";
        }
        if (!chat.getOwner().equals(currentUser)) {
            return "You don't have access to add a member!";
        }
        int index = User.getAllIds().indexOf(id);
        if (index == -1) {
            return "No user with this id exists!";
        }
        User added = User.getAllUsers().get(index);
        if (chat.getMembers().contains(added)) {
            return "This user is already in the chat!";
        }
        chat.addMember(added);
        added.addChat(chat);
        if (chat instanceof Group) {
            added.addGroup((Group)chat);
            Message newMessage = new Message(currentUser , added.getName() + " has been added to the group!");
            chat.addMessage(newMessage);
            Iterator<User> it = chat.getMembers().iterator();
            while (it.hasNext()) {
                it.next().changeOrder(chat);
            }
        } else {
            added.addChannel((Channel)chat);
            added.changeOrder(chat);
        }
        return "User has been added successfully!";
    }

    private String showMessages() {
        String result = "Messages:";
        for (Message i : chat.getMessages()) {
            result += "\n" + i.getOwner().getName() + "(" + i.getOwner().getId() + "): \"" + i.getContent() + "\"";
        }
        return result;
    }

    private String showMembers() {
        if (chat instanceof PrivateChat) {
            return "Invalid command!";
        }
        String result = "Members:";
        for (int i = 0; i != chat.getMembers().size(); i++) {
            result += "\nname: " + chat.getMembers().get(i).getName() + ", id: " + chat.getMembers().get(i).getId();
            if (chat.getOwner().equals(chat.getMembers().get(i))) {
                result += " *owner";
            }
        }
        return result;
    }
}
