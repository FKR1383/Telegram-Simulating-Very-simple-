package Menu;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Commands {
    registerRegex("register i (?<id>[\\S]+) u (?<username>[\\S]+) p (?<password>[\\S]+)"),
    loginRegex("login i (?<id>[\\S]+) p (?<password>[\\S]+)"),
    createChannelRegex("create new channel i (?<id>[\\S]+) n (?<name>[\\S]+)"),
    joinChannelRegex("join channel i (?<id>[\\S]+)"),
    createGroupRegex("create new group i (?<id>[\\S]+) n (?<name>[\\S]+)"),
    startPrivateRegex("start a new private chat with i (?<id>[\\S]+)") ,
    enterChatRegex("enter (?<type>channel|group|private chat) i (?<id>[\\S]+)"),
    sendMessageRegex("send a message c (?<message>.+)"),
    addMemberRegex("add member i (?<id>[\\S]+)");

    private String regex;

    Commands(String regex) {
        this.regex = regex;
    }

    public static Matcher getMatcher(String input , Commands command) {
        Pattern pattern = Pattern.compile(command.regex);
        return pattern.matcher(input);
    }
}
