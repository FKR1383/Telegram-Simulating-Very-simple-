package Menu;

import Chats.*;
import Users.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MessengerMenu {
    private Chat chat;
    private User currentUser;
    private static boolean running_messenger_menu = false;
    private static boolean running_chat_menu = false;

    public MessengerMenu() {

        running_messenger_menu = true;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    private static boolean checkName(String name) {
        String correctRegex = "[a-zA-Z0-9_]+";
        Pattern correctPattern = Pattern.compile(correctRegex);
        Matcher correctMatcher = correctPattern.matcher(name);
        return correctMatcher.matches();
    }

    public void run(Scanner mainScanner) {
        String command = mainScanner.nextLine();
        Matcher createChannelMatcher = Commands.getMatcher(command , Commands.createChannelRegex);
        Matcher joinChannelMatcehr = Commands.getMatcher(command , Commands.joinChannelRegex);
        Matcher createGroupMatcher = Commands.getMatcher(command , Commands.createGroupRegex);
        Matcher startPrivateMatcher = Commands.getMatcher(command , Commands.startPrivateRegex);
        Matcher enterChatMatcher = Commands.getMatcher(command , Commands.enterChatRegex);
        while (true) {
            if (command.matches("show all channels")) {
                System.out.println(showAllChannels());
            } else if (createChannelMatcher.matches()) {
                System.out.println(createChannel(createChannelMatcher));
            } else if (joinChannelMatcehr.matches()) {
                System.out.println(joinChannel(joinChannelMatcehr));
            } else if (createGroupMatcher.matches()) {
                System.out.println(createGroup(createGroupMatcher));
            } else if (startPrivateMatcher.matches()) {
                System.out.println(createPrivateChat(startPrivateMatcher));
            } else if (enterChatMatcher.matches()) {
                System.out.println(enterChat(enterChatMatcher));
                if (running_chat_menu) {
                    ChatMenu menu = new ChatMenu(chat , currentUser);
                    menu.run(mainScanner , chat);
                    running_chat_menu = false;
                }
            } else if (command.matches("logout")) {
                running_messenger_menu = false;
                System.out.println("Logged out");
                currentUser = null;
                break;
            } else if (command.matches("show my chats")) {
                System.out.println(showChats());
            } else {
                System.out.println("Invalid command!");
            }
            command = mainScanner.nextLine();
            createChannelMatcher = Commands.getMatcher(command , Commands.createChannelRegex);
            joinChannelMatcehr = Commands.getMatcher(command , Commands.joinChannelRegex);
            createGroupMatcher = Commands.getMatcher(command , Commands.createGroupRegex);
            startPrivateMatcher = Commands.getMatcher(command , Commands.startPrivateRegex);
            enterChatMatcher = Commands.getMatcher(command , Commands.enterChatRegex);
        }
    }

    private static String showAllChannels() {
        String result = "";
        result += "All channels:";
        int counter = 0;
        for (Channel i : Messenger.getChannels()) {
            result += "\n" + (++counter) + ". " + i.getName() + ", id: " + i.getId() + ", members: " + i.getMembers().size();
        }
        return result;
    }

    private String createChannel(Matcher matcher) {
        String id = matcher.group("id");
        String name = matcher.group("name");
        if (!checkName(name)) {
            return "Channel name's format is invalid!";
        } else if (Messenger.getChannelIds().contains(id)) {
            return "A channel with this id already exists!";
        } else {
            Channel newChannel = new Channel(currentUser, id, name);
            Messenger.addChannel(newChannel);
            currentUser.addChat(newChannel);
            currentUser.addChannel(newChannel);
            currentUser.changeOrder(newChannel);
            return "Channel "+ name + " has been created successfully!";
        }
    }

    private String joinChannel(Matcher matcher) {
        String id = matcher.group("id");
        if (!Messenger.getChannelIds().contains(id)) {
            return "No channel with this id exists!";
        }
        Channel channel = Messenger.getChannels().get(Messenger.getChannelIds().indexOf(id));
        if (channel.getMembers().contains(currentUser)) {
            return "You're already a member of this channel!";
        }
        currentUser.addChat(channel);
        currentUser.addChannel(channel);
        channel.addMember(currentUser);
        currentUser.changeOrder(channel);
        return "You have successfully joined the channel!";
    }

    private String showChats() {
        String result = "Chats:";
        int counter = 0;
        for (int i = currentUser.getChatsInOrder().size()-1; i >= 0; i--) {
            Chat j = currentUser.getChatsInOrder().get(i);
            result += "\n" + (++counter) + ". " + j.getName() + ", id: " + j.getId() + ", " + j.getTypeOfChat();
        }
        return result;
    }

    private String createGroup(Matcher matcher) {
        String id = matcher.group("id");
        String name = matcher.group("name");
        if (!checkName(name)) {
            return "Group name's format is invalid!";
        }
        if (Messenger.getGroupById(id) != null) {
            return "A group with this id already exists!";
        }
        Group newGroup = new Group(currentUser, id, name);
        Messenger.addGroup(newGroup);
        currentUser.addChat(newGroup);
        currentUser.addGroup(newGroup);
        currentUser.changeOrder(newGroup);
        return "Group " + name + " has been created successfully!";
    }
    private String createPrivateChat(Matcher matcher) {
        String id = matcher.group("id");
        int index = User.getAllIds().indexOf(id);
        if (index == -1) {
            return "No user with this id exists!";
        }
        User pv = Messenger.getUsers().get(index);
        if (currentUser.getPrivateChatById(id) != null) {
            return "You already have a private chat with this user!";
        }
        PrivateChat first = new PrivateChat(currentUser , id , pv.getName() , pv);
        currentUser.addPrivateChat(first);
        currentUser.addChat(first);
        currentUser.changeOrder(first);
        if (!id.equals(currentUser.getId())) {
            PrivateChat second = new PrivateChat(currentUser, currentUser.getId(), currentUser.getName(), pv);
            pv.addPrivateChat(second);
            pv.addChat(second);
            pv.changeOrder(second);
        }
        return "Private chat with " + pv.getName() + " has been started successfully!";
    }

    private String enterChat(Matcher matcher) {
        String chatType = matcher.group("type");
        String id = matcher.group("id");
        if (chatType.equals("private chat")) {
            chat = currentUser.getPrivateChatById(id);
            if (chat == null) {
                return "You have no " + chatType + " with this id!";
            }
        } else if (chatType.equals("channel")) {
            chat = currentUser.getChannelById(id);
            if (chat == null) {
                return "You have no " + chatType + " with this id!";
            }
        } else {
            chat = currentUser.getGroupById(id);
            if (chat == null) {
                return "You have no " + chatType + " with this id!";
            }
        }
        running_chat_menu = true;
        return "You have successfully entered the chat!";
    }
}
